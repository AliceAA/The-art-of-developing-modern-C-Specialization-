#pragma once


using namespace std;

// template<class T, class U>
// void AssertEqual(const T& t, const U& u,
//     const string& hint);


// class TestRunner;

// void Assert(bool cond, const std::string& hint);

void TestParseCondition() ;

